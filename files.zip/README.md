# 🫀 Sistema Predictivo DIALYSIS

Sistema de identificación y seguimiento del riesgo cardio-reno-metabólico basado en IA y datos ENSANUT 2022.

- **Modelo:** XGBoost · ROC-AUC 95.9% · Validación k-fold k=5
- **Variables:** 28 biomarcadores clínicos y factores conductuales (sin tensión arterial)
- **Dataset:** ENSANUT 2022 (n=4,363)

## Archivos del repositorio

```
├── app.py                        # Aplicación Streamlit
├── requirements.txt              # Dependencias Python
├── modelo_dialysis.pkl           # Modelo XGBoost entrenado
├── features_dialysis.pkl         # Lista de features del modelo
├── Hipertension_Arterial_Mexico.csv  # Dataset ENSANUT 2022
└── generar_modelo.py             # Script para regenerar el modelo
```

## Cómo regenerar el modelo (solo si es necesario)

Si los archivos `.pkl` no están disponibles, ejecuta en Colab o localmente:

```bash
python generar_modelo.py
```

## Despliegue en Streamlit Community Cloud

1. Sube este repositorio a GitHub
2. Ve a [share.streamlit.io](https://share.streamlit.io)
3. Conecta tu cuenta de GitHub
4. Selecciona el repositorio y el archivo `app.py`
5. Click en **Deploy**

## Aviso

Herramienta de apoyo predictivo. No sustituye la valoración médica clínica.
Resultados deben ser interpretados por personal de salud calificado.
